from fastapi import APIRouter, HTTPException
from typing import Dict

from app.services.auth_service import authenticate_user, create_jwt_token

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.post("/login")
async def login(user_credentials: Dict) -> Dict:
    """Logs in a user."""
    user = await authenticate_user(user_credentials.get("email"), user_credentials.get("password"))
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    access_token = create_jwt_token(data={"sub": user.email, "role": user.role})
    return {"access_token": access_token, "token_type": "bearer"}