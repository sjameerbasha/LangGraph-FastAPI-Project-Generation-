from fastapi import APIRouter, Depends
from typing import Dict

from app.services.auth_service import get_current_user, User

router = APIRouter(prefix="/api/auth", tags=["Authentication"])


@router.get("/user")
async def get_user(current_user: User = Depends(get_current_user)) -> Dict:
    """Returns user information. Requires authentication."""
    return {"email": current_user.email, "role": current_user.role}