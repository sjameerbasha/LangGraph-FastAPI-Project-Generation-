from fastapi import APIRouter, Depends, HTTPException
from typing import List, Dict

from app.services.auth_service import get_current_user, User

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/tiles")
async def get_dashboard_tiles(current_user: User = Depends(get_current_user)) -> List[Dict]:
    """Returns dashboard tiles. Requires authentication."""
    # Dummy data for dashboard tiles
    tiles = [
        {"title": "Leaves Applied", "count": 10},
        {"title": "Pods Created", "count": 5},
        {"title": "Users Active", "count": 25}
    ]
    return tiles