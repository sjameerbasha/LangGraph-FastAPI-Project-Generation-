from fastapi import APIRouter, Depends, HTTPException
from typing import Dict

from app.services.auth_service import get_current_user, User

router = APIRouter(prefix="/api/lms/leaves", tags=["Leaves"])


@router.post("/apply")
async def apply_for_leave(current_user: User = Depends(get_current_user)) -> Dict:
    """Applies for a leave. Requires authentication."""
    # Dummy implementation
    return {"message": f"Leave application submitted for user {current_user.email}"}