from fastapi import APIRouter, Depends, HTTPException
from typing import Dict

from app.services.auth_service import get_current_user, User

router = APIRouter(prefix="/api/lms/leaves", tags=["Leaves"])


@router.patch("/{leave_id}/approve")
async def approve_leave(leave_id: int, current_user: User = Depends(get_current_user)) -> Dict:
    """Approves a leave. Requires authentication."""
    # Dummy implementation
    if current_user.role != "manager":
        raise HTTPException(status_code=403, detail="Insufficient permissions")
    return {"message": f"Leave {leave_id} approved"}