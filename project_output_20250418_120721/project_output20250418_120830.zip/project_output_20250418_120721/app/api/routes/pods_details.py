from fastapi import APIRouter, Depends, HTTPException
from typing import Dict

from app.services.auth_service import get_current_user, User

router = APIRouter(prefix="/api/pods", tags=["Pods"])


@router.get("/{pod_id}/details")
async def get_pod_details(pod_id: int, current_user: User = Depends(get_current_user)) -> Dict:
    """Returns pod details. Requires authentication."""
    # Dummy implementation
    return {"pod_id": pod_id, "name": f"Pod {pod_id}", "members": ["user1", "user2"]}