from fastapi import APIRouter, Depends, HTTPException
from typing import Dict

from app.services.auth_service import get_current_user, User

router = APIRouter(prefix="/api/pods", tags=["Pods"])


@router.post("/{pod_id}/recommend")
async def recommend_pod(pod_id: int, current_user: User = Depends(get_current_user)) -> Dict:
    """Recommends a pod. Requires authentication."""
    # Dummy implementation
    return {"message": f"Pod {pod_id} recommended to user {current_user.email}"}