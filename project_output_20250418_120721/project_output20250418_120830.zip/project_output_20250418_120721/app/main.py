import logging
import os

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from app.api.routes import dashboard_tiles, lms_leaves_apply, lms_leaves_approve, pods_details, pods_recommend, auth_login, auth_user

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="LMS and Pods API", version="0.1.0")

# CORS configuration
origins = ["*"]  # Adjust this in production to specific origins

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(dashboard_tiles.router)
app.include_router(lms_leaves_apply.router)
app.include_router(lms_leaves_approve.router)
app.include_router(pods_details.router)
app.include_router(pods_recommend.router)
app.include_router(auth_login.router)
app.include_router(auth_user.router)


@app.get("/")
async def read_root():
    """Root endpoint."""
    return {"message": "Welcome to the LMS and Pods API"}
