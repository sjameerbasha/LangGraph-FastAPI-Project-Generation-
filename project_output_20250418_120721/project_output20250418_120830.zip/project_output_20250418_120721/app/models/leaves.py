from typing import Optional
from pydantic import BaseModel

class Leave(BaseModel):
    id: int
    start_date: str
    end_date: str
    reason: str
    status: str
