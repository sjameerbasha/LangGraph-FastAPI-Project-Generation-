from typing import List
from pydantic import BaseModel

class Pod(BaseModel):
    id: int
    name: str
    members: List[str]
