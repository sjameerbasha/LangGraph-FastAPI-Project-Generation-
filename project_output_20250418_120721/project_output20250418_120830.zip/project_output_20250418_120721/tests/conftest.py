import pytest
from typing import Generator
from fastapi import FastAPI
from fastapi.testclient import TestClient

from app.main import app


@pytest.fixture(scope="session")
def test_app() -> Generator[FastAPI, None, None]:
    yield app


@pytest.fixture(scope="session")
def test_client(test_app: FastAPI) -> Generator[TestClient, None, None]:
    with TestClient(test_app) as client:
        yield client