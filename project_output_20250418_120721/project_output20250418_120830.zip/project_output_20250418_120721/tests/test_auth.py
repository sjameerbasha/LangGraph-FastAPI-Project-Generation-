import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.services import auth_service
from app.models import user_model
from unittest.mock import patch

client = TestClient(app)

@pytest.fixture
def mock_user():
    return user_model.User(id=1, name="Test User", role="admin", email="test@example.com")

@pytest.fixture
def mock_token():
    return "test_jwt_token"

@pytest.mark.asyncio
async def test_login_success():
    with patch("app.services.auth_service.authenticate_user", return_value=True),
         patch("app.services.auth_service.create_jwt_token", return_value="test_token"):
        response = client.post("/api/auth/login", json={"username": "test", "password": "test"})
        assert response.status_code == 200
        assert "access_token" in response.json()

@pytest.mark.asyncio
async def test_login_failure():
    with patch("app.services.auth_service.authenticate_user", return_value=False):
        response = client.post("/api/auth/login", json={"username": "test", "password": "test"})
        assert response.status_code == 401
        assert response.json() == {"detail": "Incorrect username or password"}

@pytest.mark.asyncio
async def test_get_user_success(mock_user, mock_token):
    with patch("app.services.auth_service.get_current_user", return_value=mock_user):
        response = client.get("/api/auth/user", headers={"Authorization": f"Bearer {mock_token}"})
        assert response.status_code == 200
        assert response.json() == mock_user.dict()

@pytest.mark.asyncio
async def test_get_user_unauthorized():
    response = client.get("/api/auth/user")
    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}

@pytest.mark.asyncio
async def test_get_user_invalid_token():
    with patch("app.services.auth_service.get_current_user", side_effect=Exception("Invalid token")):
        response = client.get("/api/auth/user", headers={"Authorization": "Bearer invalid_token"})
        assert response.status_code == 401
        assert response.json() == {"detail": "Not authenticated"}