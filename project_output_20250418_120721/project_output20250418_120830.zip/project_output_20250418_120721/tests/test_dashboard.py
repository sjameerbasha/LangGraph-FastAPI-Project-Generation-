import pytest
from fastapi.testclient import TestClient
from app.main import app
from unittest.mock import patch

client = TestClient(app)

@pytest.mark.asyncio
async def test_get_dashboard_tiles_success():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.dashboard_service.get_dashboard_tiles", return_value=[{"title": "Tile 1", "value": 10}]):  # Mock the dashboard service
        response = client.get("/api/dashboard/tiles", headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 200
        assert response.json() == [{"title": "Tile 1", "value": 10}]

@pytest.mark.asyncio
async def test_get_dashboard_tiles_unauthorized():
    response = client.get("/api/dashboard/tiles")
    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}

@pytest.mark.asyncio
async def test_get_dashboard_tiles_service_error():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.dashboard_service.get_dashboard_tiles", side_effect=Exception("Service error")):
        response = client.get("/api/dashboard/tiles", headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 500
        assert response.json() == {"detail": "Internal Server Error"}