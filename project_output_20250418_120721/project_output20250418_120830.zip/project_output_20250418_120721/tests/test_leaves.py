import pytest
from fastapi.testclient import TestClient
from app.main import app
from unittest.mock import patch

client = TestClient(app)

@pytest.mark.asyncio
async def test_apply_leave_success():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.leave_service.apply_leave", return_value={"id": 1, "status": "pending"}):
        response = client.post("/api/lms/leaves/apply", json={"start_date": "2024-01-01", "end_date": "2024-01-05", "reason": "Vacation"}, headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 200
        assert response.json() == {"id": 1, "status": "pending"}

@pytest.mark.asyncio
async def test_apply_leave_unauthorized():
    response = client.post("/api/lms/leaves/apply", json={"start_date": "2024-01-01", "end_date": "2024-01-05", "reason": "Vacation"})
    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}

@pytest.mark.asyncio
async def test_apply_leave_invalid_data():
    with patch("app.services.auth_service.get_current_user", return_value=True):
        response = client.post("/api/lms/leaves/apply", json={"start_date": "invalid", "end_date": "2024-01-05", "reason": "Vacation"}, headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 422

@pytest.mark.asyncio
async def test_approve_leave_success():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.leave_service.approve_leave", return_value={"id": 1, "status": "approved"}):
        response = client.patch("/api/lms/leaves/1/approve", headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 200
        assert response.json() == {"id": 1, "status": "approved"}

@pytest.mark.asyncio
async def test_approve_leave_unauthorized():
    response = client.patch("/api/lms/leaves/1/approve")
    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}

@pytest.mark.asyncio
async def test_approve_leave_not_found():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.leave_service.approve_leave", return_value=None):
        response = client.patch("/api/lms/leaves/999/approve", headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 404
        assert response.json() == {"detail": "Leave not found"}