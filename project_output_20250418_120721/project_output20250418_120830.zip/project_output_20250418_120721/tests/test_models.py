import pytest
from app.models import user_model, leave_model, pod_model

@pytest.fixture
def user_data():
    return {"id": 1, "name": "Test User", "role": "admin", "email": "test@example.com"}

@pytest.fixture
def leave_data():
    return {"id": 1, "start_date": "2024-01-01", "end_date": "2024-01-05", "reason": "Vacation", "status": "pending"}

@pytest.fixture
def pod_data():
    return {"id": 1, "name": "Test Pod", "members": [1, 2, 3]}


def test_user_model(user_data):
    user = user_model.User(**user_data)
    assert user.id == user_data["id"]
    assert user.name == user_data["name"]
    assert user.role == user_data["role"]
    assert user.email == user_data["email"]


def test_leave_model(leave_data):
    leave = leave_model.Leave(**leave_data)
    assert leave.id == leave_data["id"]
    assert leave.start_date == leave_data["start_date"]
    assert leave.end_date == leave_data["end_date"]
    assert leave.reason == leave_data["reason"]
    assert leave.status == leave_data["status"]


def test_pod_model(pod_data):
    pod = pod_model.Pod(**pod_data)
    assert pod.id == pod_data["id"]
    assert pod.name == pod_data["name"]
    assert pod.members == pod_data["members"]