import pytest
from fastapi.testclient import TestClient
from app.main import app
from unittest.mock import patch

client = TestClient(app)

@pytest.mark.asyncio
async def test_get_pod_details_success():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.pod_service.get_pod_details", return_value={"id": 1, "name": "Pod 1"}):
        response = client.get("/api/pods/1/details", headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 200
        assert response.json() == {"id": 1, "name": "Pod 1"}

@pytest.mark.asyncio
async def test_get_pod_details_unauthorized():
    response = client.get("/api/pods/1/details")
    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}

@pytest.mark.asyncio
async def test_get_pod_details_not_found():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.pod_service.get_pod_details", return_value=None):
        response = client.get("/api/pods/999/details", headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 404
        assert response.json() == {"detail": "Pod not found"}

@pytest.mark.asyncio
async def test_recommend_pod_success():
    with patch("app.services.auth_service.get_current_user", return_value=True),
         patch("app.services.pod_service.recommend_pod", return_value={"message": "Recommendation sent"}):
        response = client.post("/api/pods/1/recommend", json={"user_id": 2}, headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 200
        assert response.json() == {"message": "Recommendation sent"}

@pytest.mark.asyncio
async def test_recommend_pod_unauthorized():
    response = client.post("/api/pods/1/recommend", json={"user_id": 2})
    assert response.status_code == 401
    assert response.json() == {"detail": "Not authenticated"}

@pytest.mark.asyncio
async def test_recommend_pod_invalid_data():
    with patch("app.services.auth_service.get_current_user", return_value=True):
        response = client.post("/api/pods/1/recommend", json={"user_id": "invalid"}, headers={"Authorization": "Bearer test_token"})
        assert response.status_code == 422