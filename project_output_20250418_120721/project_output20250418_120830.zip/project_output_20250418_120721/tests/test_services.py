import pytest
from app.services import auth_service, leave_service, pod_service, dashboard_service
from app.models import user_model
from unittest.mock import patch

@pytest.fixture
def mock_user():
    return user_model.User(id=1, name="Test User", role="admin", email="test@example.com")

@pytest.mark.asyncio
async def test_authenticate_user_success(mock_user):
    with patch("app.database.get_user_by_username", return_value=mock_user),
         patch("app.services.auth_service.verify_password", return_value=True):
        user = await auth_service.authenticate_user("test", "test")
        assert user == mock_user

@pytest.mark.asyncio
async def test_authenticate_user_failure():
    with patch("app.database.get_user_by_username", return_value=None):
        user = await auth_service.authenticate_user("test", "test")
        assert user is None

@pytest.mark.asyncio
async def test_get_current_user_success(mock_user):
    with patch("app.services.auth_service.decode_jwt_token", return_value={"sub": "test@example.com"}),
         patch("app.database.get_user_by_email", return_value=mock_user):
        user = await auth_service.get_current_user("test_token")
        assert user == mock_user

@pytest.mark.asyncio
async def test_get_current_user_invalid_token():
    with patch("app.services.auth_service.decode_jwt_token", side_effect=Exception("Invalid token")):
        with pytest.raises(Exception, match="Invalid token"):
            await auth_service.get_current_user("invalid_token")

@pytest.mark.asyncio
async def test_apply_leave_success():
    with patch("app.database.create_leave", return_value={"id": 1, "status": "pending"}):
        leave = await leave_service.apply_leave(1, "2024-01-01", "2024-01-05", "Vacation")
        assert leave == {"id": 1, "status": "pending"}

@pytest.mark.asyncio
async def test_approve_leave_success():
    with patch("app.database.get_leave", return_value={"id": 1, "status": "pending"}),
         patch("app.database.update_leave", return_value={"id": 1, "status": "approved"}):
        leave = await leave_service.approve_leave(1)
        assert leave == {"id": 1, "status": "approved"}

@pytest.mark.asyncio
async def test_approve_leave_not_found():
    with patch("app.database.get_leave", return_value=None):
        leave = await leave_service.approve_leave(1)
        assert leave is None

@pytest.mark.asyncio
async def test_get_pod_details_success():
    with patch("app.database.get_pod", return_value={"id": 1, "name": "Pod 1"}):
        pod = await pod_service.get_pod_details(1)
        assert pod == {"id": 1, "name": "Pod 1"}

@pytest.mark.asyncio
async def test_get_pod_details_not_found():
    with patch("app.database.get_pod", return_value=None):
        pod = await pod_service.get_pod_details(1)
        assert pod is None

@pytest.mark.asyncio
async def test_recommend_pod_success():
    with patch("app.database.create_recommendation", return_value=True):
        result = await pod_service.recommend_pod(1, 2)
        assert result == {"message": "Recommendation sent"}

@pytest.mark.asyncio
async def test_get_dashboard_tiles_success():
    with patch("app.database.get_leave_count", return_value=10),
         patch("app.database.get_pod_count", return_value=5),
         patch("app.database.get_user_count", return_value=20):
        tiles = await dashboard_service.get_dashboard_tiles()
        assert len(tiles) == 3
        assert tiles[0]["title"] == "Leaves"
        assert tiles[0]["value"] == 10